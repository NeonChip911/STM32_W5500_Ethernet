/*
 * http_server_example.c
 *
 *  Created on: Nov 15, 2025
 *      Author: controllerstech
 */

#include "main.h"
#include "wizchip_conf.h"
#include "socket.h"
#include "httpServer/httpServer.h"
#include "httpServer/httpParser.h"
#include <string.h>
#include <stdio.h>


#define HTTP_MAX_SOCK 2
uint8_t sockList[] = {0, 1};

uint8_t rx_buf[1024];
uint8_t tx_buf[1024];


// --- LED Control Function ---
extern void led_Control(uint8_t state);

const uint8_t index_page[] =
		"<!DOCTYPE html>"
		"<html><body>"
		"<h2>LED Control</h2>"
		"<a href='/led_on.html'><button>LED ON</button></a><br><br>"
		"<a href='/led_off.html'><button>LED OFF</button></a>"
		"</body></html>";

const uint8_t led_on_page[] =
		"<!DOCTYPE html>"
		"<html><body>"
		"<h2>LED is ON</h2>"
		"<a href='/led_off.html'><button>LED OFF</button></a><br><br>"
		"<a href='/index.html'><button>HOME</button></a>"
		"</body></html>";

const uint8_t led_off_page[] =
		"<!DOCTYPE html>"
		"<html><body>"
		"<h2>LED is OFF</h2>"
		"<a href='/led_on.html'><button>LED ON</button></a><br><br>"
		"<a href='/index.html'><button>HOME</button></a>"
		"</body></html>";



// HTTP Server Setup
void httpServer_setup(void)
{
    httpServer_init(tx_buf, rx_buf, HTTP_MAX_SOCK, sockList);

    reg_httpServer_cbfunc(NVIC_SystemReset, NULL);

    /* Register Static pages */
    reg_httpServer_webContent((uint8_t*)"index.html", (uint8_t*)index_page);
    reg_httpServer_webContent((uint8_t*)"led_on.html",  (uint8_t*)led_on_page);
    reg_httpServer_webContent((uint8_t*)"led_off.html", (uint8_t*)led_off_page);
}

// Call this inside the while loop
void httpServerRun (void)
{
    for (int sn = 0; sn < HTTP_MAX_SOCK; sn++){
    	httpServer_run(sn);
    }
}


// Function to handle the custom requests
// Call it inside HTTPserver.c file, inside http_process_handler() function.
void http_dynamic_handler(st_http_request * p_http_request)
{
	if (strstr((char*)p_http_request->URI, "led_on"))
	{
	    led_Control(1);
	}
	else if (strstr((char*)p_http_request->URI, "led_off"))
	{
	    led_Control(0);
	}
}
